#ifndef BinaryEncryptionCheck_h
#define BinaryEncryptionCheck_h

bool isBinaryEncrypted(void);

#endif /* BinaryEncryption_h */
